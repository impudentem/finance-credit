<?php

$server_host = $_SERVER['SERVER_NAME'];

if ($server_host == "localhost" || $server_host == "192.168.0.101") {
    include './local.min.html';
} else {
    include './prod.min.html';
}
