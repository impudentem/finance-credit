<?php

$server_host = $_SERVER['SERVER_NAME'];

if ($server_host == "localhost") {
  include './local.min.html';
} else {
  include './prod.min.html';
}

?>