<?php
  //------------------- Edit here --------------------//
  $sendy_url = 'http://e.finance.ua';
  $list = 'CiPcQzoyPOuKGx83892gWZqA';
  //------------------ /Edit here --------------------//

  //--------------------------------------------------//
  //POST variables
  // $name = $_POST['name'];
  // 'name' => $name,
  // $params = $_GET['params'];
  // $email = $params->email;
  $email = $_GET['email'];

  //subscribe
  $postdata = http_build_query(
      array(
      'email' => $email,
      'list' => $list,
      'boolean' => 'true'
      )
  );
  $opts = array('http' => array('method'  => 'POST', 'header'  => 'Content-type: application/x-www-form-urlencoded', 'content' => $postdata));
  $context  = stream_context_create($opts);
  $result = file_get_contents($sendy_url.'/subscribe', false, $context);
  //--------------------------------------------------//

  echo $result;
?>